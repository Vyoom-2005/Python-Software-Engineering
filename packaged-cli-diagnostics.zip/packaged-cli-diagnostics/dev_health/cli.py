from __future__ import annotations

import argparse
import sys

from .checks import run_checks
from .config import ConfigError, load_config
from .events import EventsError, load_events, summarize_events
from .report import build_report, exit_code, render_json, render_text


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dev-health",
        description="Inspect a developer machine and produce a deterministic health report.",
    )
    parser.add_argument("--config", help="Path to a JSON configuration file.")
    parser.add_argument("--events", help="Path to diagnostic-events JSON.")
    parser.add_argument("--json", action="store_true", help="Print structured JSON.")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)

    try:
        config = load_config(args.config) if args.config else {"required_tools": [], "paths": []}
        event_summary = None
        if args.events:
            event_summary = summarize_events(load_events(args.events))

        report = build_report(
            run_checks(config["required_tools"], config["paths"]),
            event_summary,
        )
        print(render_json(report) if args.json else render_text(report))
        return exit_code(report)

    except (ConfigError, EventsError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except Exception as exc:
        print(f"ERROR: unexpected failure: {exc}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
