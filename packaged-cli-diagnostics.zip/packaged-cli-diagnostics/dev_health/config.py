from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


class ConfigError(ValueError):
    pass


def load_config(path: str) -> Dict[str, Any]:
    config_path = Path(path)
    if not config_path.exists():
        raise ConfigError(f"configuration path does not exist: {config_path}")
    if not config_path.is_file():
        raise ConfigError(f"configuration path is not a file: {config_path}")

    try:
        data = json.loads(config_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ConfigError(f"malformed JSON configuration: {exc}") from exc
    except OSError as exc:
        raise ConfigError(f"cannot read configuration: {exc}") from exc

    if not isinstance(data, dict):
        raise ConfigError("configuration root must be a JSON object")

    required_tools = data.get("required_tools", [])
    paths = data.get("paths", [])

    if not isinstance(required_tools, list) or not all(
        isinstance(item, str) and item.strip() for item in required_tools
    ):
        raise ConfigError("required_tools must be an array of non-empty strings")

    if not isinstance(paths, list) or not all(
        isinstance(item, str) and item.strip() for item in paths
    ):
        raise ConfigError("paths must be an array of non-empty strings")

    unknown = set(data) - {"required_tools", "paths"}
    if unknown:
        raise ConfigError("unknown configuration keys: " + ", ".join(sorted(unknown)))

    return {
        "required_tools": sorted(set(required_tools)),
        "paths": sorted(set(paths)),
    }
