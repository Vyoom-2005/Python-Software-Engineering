from __future__ import annotations

import json
from typing import Dict, List, Optional


def build_report(results: List[Dict], event_summary: Optional[Dict] = None) -> Dict:
    failures = [item for item in results if item["status"] == "FAIL"]
    report = {
        "tool": "dev-health",
        "version": "1.0.0",
        "summary": {
            "status": "FAIL" if failures else "PASS",
            "checks": len(results),
            "failed": len(failures),
        },
        "checks": results,
    }
    if event_summary is not None:
        report["diagnostic_events"] = event_summary
    return report


def exit_code(report: Dict) -> int:
    return 1 if report["summary"]["failed"] else 0


def render_text(report: Dict) -> str:
    lines = [
        f"{report['tool']} {report['version']}",
        "=" * 40,
        f"Overall status: {report['summary']['status']}",
        f"Checks: {report['summary']['checks']} | Failed: {report['summary']['failed']}",
        "",
        "Checks:",
    ]
    for check in report["checks"]:
        lines.append(f"- [{check['status']}] {check['name']}: {check['details']}")
    if "diagnostic_events" in report:
        event = report["diagnostic_events"]
        lines.extend([
            "",
            "Diagnostic events:",
            f"- Total: {event['total_events']}",
            f"- INFO: {event['levels']['INFO']}",
            f"- WARN: {event['levels']['WARN']}",
            f"- ERROR: {event['levels']['ERROR']}",
            f"- Average latency: {event['average_latency_ms']} ms",
            f"- Max latency: {event['max_latency_ms']} ms",
        ])
    return "\n".join(lines)


def render_json(report: Dict) -> str:
    return json.dumps(report, indent=2, sort_keys=True)
