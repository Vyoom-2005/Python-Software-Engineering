from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List


class EventsError(ValueError):
    pass


def load_events(path: str) -> List[Dict]:
    event_path = Path(path)
    if not event_path.exists() or not event_path.is_file():
        raise EventsError(f"events path does not exist or is not a file: {event_path}")

    try:
        data = json.loads(event_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise EventsError(f"malformed events JSON: {exc}") from exc

    if not isinstance(data, dict) or not isinstance(data.get("events"), list):
        raise EventsError("events input must contain an 'events' array")

    return data["events"]


def summarize_events(events: List[Dict]) -> Dict:
    levels = {"INFO": 0, "WARN": 0, "ERROR": 0}
    services = {}
    latencies = []

    for event in events:
        level = event.get("level")
        if level in levels:
            levels[level] += 1
        service = event.get("service", "unknown")
        services[service] = services.get(service, 0) + 1
        latency = event.get("latency_ms")
        if isinstance(latency, (int, float)):
            latencies.append(latency)

    return {
        "total_events": len(events),
        "levels": levels,
        "services": dict(sorted(services.items())),
        "average_latency_ms": round(sum(latencies) / len(latencies), 2) if latencies else None,
        "max_latency_ms": max(latencies) if latencies else None,
    }
