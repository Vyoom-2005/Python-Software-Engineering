from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List


DEFAULT_TOOLS = ("git", "docker", "node", "npm", "pip", "poetry", "pytest", "uv")


def python_check() -> Dict:
    return {
        "name": "python",
        "status": "PASS",
        "details": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "executable": str(Path(sys.executable).resolve()),
    }


def disk_check(path: str = ".") -> Dict:
    target = Path(path).resolve()
    try:
        usage = shutil.disk_usage(target)
    except OSError as exc:
        return {"name": "disk", "status": "FAIL", "details": str(exc)}
    free_gb = usage.free / (1024 ** 3)
    total_gb = usage.total / (1024 ** 3)
    return {
        "name": "disk",
        "status": "PASS" if usage.free > 0 else "FAIL",
        "details": f"{free_gb:.2f} GiB free of {total_gb:.2f} GiB",
        "free_bytes": usage.free,
        "total_bytes": usage.total,
    }


def environment_check() -> Dict:
    names = sorted(os.environ)
    return {
        "name": "environment",
        "status": "PASS",
        "details": f"{len(names)} environment variables detected",
        "variables": names,
    }


def command_check(command: str) -> Dict:
    resolved = shutil.which(command)
    if resolved is None:
        return {
            "name": f"tool:{command}",
            "status": "FAIL",
            "details": "command not found",
        }

    version = ""
    try:
        completed = subprocess.run(
            [resolved, "--version"],
            capture_output=True,
            text=True,
            timeout=3,
            check=False,
        )
        output = (completed.stdout or completed.stderr).strip().splitlines()
        version = output[0] if output else ""
    except (OSError, subprocess.SubprocessError):
        version = ""

    return {
        "name": f"tool:{command}",
        "status": "PASS",
        "details": version or "command found",
        "path": resolved,
    }


def configured_path_check(path: str) -> Dict:
    target = Path(path)
    exists = target.exists()
    return {
        "name": f"path:{path}",
        "status": "PASS" if exists else "FAIL",
        "details": "exists" if exists else "path does not exist",
        "resolved": str(target.resolve()) if exists else None,
    }


def run_checks(required_tools: List[str], paths: List[str]) -> List[Dict]:
    results = [python_check(), disk_check(), environment_check()]
    for tool in DEFAULT_TOOLS:
        results.append(command_check(tool))
    for tool in sorted(set(required_tools)):
        if tool not in DEFAULT_TOOLS:
            results.append(command_check(tool))
    for path in sorted(set(paths)):
        results.append(configured_path_check(path))
    return results
