import unittest

from dev_health.events import summarize_events


class EventTests(unittest.TestCase):
    def test_sample_event_summary(self):
        events = [
            {"service": "billing-api", "level": "INFO", "latency_ms": 148},
            {"service": "billing-api", "level": "WARN", "latency_ms": 920},
            {"service": "profile-api", "level": "ERROR", "latency_ms": 1210},
            {"service": "profile-api", "level": "INFO", "latency_ms": 205},
            {"service": "billing-api", "level": "ERROR", "latency_ms": None},
        ]
        result = summarize_events(events)
        self.assertEqual(result["total_events"], 5)
        self.assertEqual(result["levels"]["ERROR"], 2)
        self.assertEqual(result["services"]["billing-api"], 3)
        self.assertEqual(result["max_latency_ms"], 1210)
        self.assertEqual(result["average_latency_ms"], 620.75)


if __name__ == "__main__":
    unittest.main()
