import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from dev_health.cli import main


class CLITests(unittest.TestCase):
    def test_success(self):
        with patch("dev_health.checks.DEFAULT_TOOLS", ("python",)):
            code = main(["--json"])
        self.assertEqual(code, 0)

    def test_missing_dependency(self):
        with patch("dev_health.checks.DEFAULT_TOOLS", ("definitely-missing-tool-xyz",)):
            code = main(["--json"])
        self.assertEqual(code, 1)

    def test_malformed_configuration_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "broken.json"
            path.write_text("{", encoding="utf-8")
            code = main(["--config", str(path)])
        self.assertEqual(code, 2)


if __name__ == "__main__":
    unittest.main()
