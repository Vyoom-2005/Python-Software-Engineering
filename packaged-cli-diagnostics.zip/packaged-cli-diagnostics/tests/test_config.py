import json
import tempfile
import unittest
from pathlib import Path

from dev_health.config import ConfigError, load_config


class ConfigTests(unittest.TestCase):
    def test_malformed_configuration_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "broken.json"
            path.write_text("{not-json", encoding="utf-8")
            with self.assertRaises(ConfigError):
                load_config(str(path))

    def test_missing_configuration_path(self):
        with self.assertRaises(ConfigError):
            load_config("does-not-exist.json")

    def test_valid_configuration(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "config.json"
            path.write_text(json.dumps({
                "required_tools": ["git", "git"],
                "paths": ["."]
            }), encoding="utf-8")
            result = load_config(str(path))
            self.assertEqual(result["required_tools"], ["git"])
            self.assertEqual(result["paths"], ["."])


if __name__ == "__main__":
    unittest.main()
